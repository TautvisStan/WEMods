# UnlimitedParticles
Greatly increases the particle limit (such as blood strains) and makes them never expire.

Credits: IngoH for making puddles last longer.

Note: too many particle effects at once might impact game performance. You can modify the global particle limit in the config file.