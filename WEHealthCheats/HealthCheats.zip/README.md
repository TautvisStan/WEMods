# HealthCheats
Hold `Left Alt` to apply that to your target, otherwise it will applied to your character instead.
List of cheats:
- `Q` - Sets health to max
- `W` - Sets health to 0
- `E` - Sets stun to max
- `R` - Sets stun to 0
- `T` - Sets "blindness" to max
- `Y` - Sets "blindness" to 0
- `D` - Sets adrenaline to max
- `F` - Sets adrenaline to 0
- `G` - Sets adrenaline timer to max
- `H` - Ends the adrenaline timer