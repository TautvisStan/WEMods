# CareerMatchRatings
This mod enables the match ratings display for exibition & wrestler career matches.

Note that this mod does not work properly when you interfere in other matches and I probably won't fix this.