# BookerWinrateTracker
This mod will track your booker mode wrestler wins, draws and losses. Tracks only for people in your fed. Winrates are saved in a Winrates.json file.

Advanced winrate display can be enabled in the config file, it will separate the singles, team, and countdown match winrates.

Note: the wrestler winrate will reset if they leave your fed.