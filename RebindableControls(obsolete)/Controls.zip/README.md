# RebindableControls
This mod lets you rebind keyboard controls.

Open the game, then you can change the keyboard controls in the mod config file. Keybinds that can be changed:
- Movement (arrow keys)
- Attack (A)
- Grapple (S)
- Run (Z)
- Pick up (X)
- Taunt (Space)
- Change focus (Control and Shift)
- Change control (Tab)
- Join the game (NEW) - previously was only available on the controller, now you can join a match in progress (eg. AI only match)

Changing `Esc` and `P` to different buttons is currently not supported.