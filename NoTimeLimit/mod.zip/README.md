# NoTimeLimits
Makes all* matches in your wrestling career have no time limits.

Note: these match types will still have time limits as intended: Race against time, Most falls win (ironman), Last fall win (last laugh).