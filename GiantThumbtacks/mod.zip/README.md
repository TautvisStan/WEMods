# GiantThumbtacks
This mod makes bag of thumbtacks spawn giant tacks. The size can be customized in the config file.

Because we put "Death" in "DeathMatch"!