# OnePunch
Inspired by the YoungFro video, your wrestler career character attacks will instantly remove all health from the target.

**SHOULD NOW ALSO WORK WITH GRAPPLE ATTACKS AND SUBMISSION STRIKES**

Injuries or knockouts on hit can be toggled in the config file.

Note: knockouts in the ring will result in knocked out character getting DQ'd, that's how the game handles knock outs by default.