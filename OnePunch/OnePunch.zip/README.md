# OnePunch
Inspired by the YoungFro video, your wrestler career character punches and strikes will instantly remove all health from the target.

**DUE TO LIMITATIONS IT CURRENTLY DOESN'T WORK ON GRAPPLE ATTACKS**

Injuries or knockouts on hit can be toggled in the config file.

Note: knockouts in the ring will result in knocked out character getting DQ'd, that's how the game handles knock outs by default.