Now works with the new dialog system.

Hold N during the dialogue to force anyone accept your requests.