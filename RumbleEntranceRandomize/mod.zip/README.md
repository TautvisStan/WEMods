# RumbleEntranceRandomize
In career mode, countdown (rumble) and gauntlet match entrance order will be randomized, meaning that your character will no longer be guaranteed to be the one starting the match. Note that your character might still be randomized to be starting wrestler. 

Note that you will still have to spectate the match until your character walks out.

Once the match starts, you can check console to know when to expect to see your character.