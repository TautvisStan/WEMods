# NoFurnitureMovement
Wrestler contact with furniture will no longer push it away. Requested by Nifty.

You can configure which furniture can be moved by wrestler contact in the config file. By default, only Office Chair, Ladder, Wooden Crate, Cardboard Box, Trashcan, Stool, Barrel, Wheelchair, Stretcher can be moved by wrestler collision.

Furniture ID list (as of 1.6.1):
```
1: Table
2: Office Chair
3: Announce Desk
4: Steps
5: Desk
6: Bench
7: Ladder
8: Wooden Crate
9: Cardboard Box
10:Trashcan
11:Toilet
12:Bed
13:Snooker Table
14:Stool
15:Round Table
16:Barrel
17:Coffin
18:Wheelchair
19:Folding Chair
24:Vending Machine
26:Piano
33:Stretcher
```