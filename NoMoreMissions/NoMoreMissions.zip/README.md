# NoMoreMissions

Hey, are you tired of bookers giving you impossible tasks? Hearing words `Listen [Name], I've been keeping an eye on your progress...` give you PTSD? This mod will make them a thing of the past! Works even in the Booker mode! Note: if you are already on a mission, you still have to complete it.