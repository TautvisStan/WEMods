# Increased Slider Limits

WARNING! HIGHLY LIKELY TO BREAK THE GAME! USE AT YOUR OWN RISK!

Slider limits can be modified in the config file. Currently possible to change the limits for:
- Height
- Theme speed
- Popularity
- Strength
- Skill
- Agility
- Stamina
- Attitude
