# ExplodingBarbedWireBat
Exploding Barbed Wire Bat

This mod makes barbed bats create explosions on contact. You can modify the explosion size and toggle creating explosions when the bat is thrown in the config file.

Because we put "Death" in "DeathMatch"!