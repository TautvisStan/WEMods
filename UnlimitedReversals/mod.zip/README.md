# UnlimitedReversals
Will apply to your career character. If possible, all strikes, grapple moves and submissions will be reversed as long as you hold the attack button. Note that there are a bunch of non-reversable moves. Non-reversable submissions will instantly be broken instead.

Additional option in the config file lets you to disable botches (where both characters fall down instead).