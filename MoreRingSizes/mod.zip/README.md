# MoreRingSizes
Experimental mod, ring size can now be selected between 20% - 165%. Going above the default limit is currently only supported on arena locations.

Going beyond default ring sizes might make ring collisions a bit funky.