# ExhibitionClones
Lets you select multiples of the same character in exhibition mode. Additional config option allows you to use it in booker mode as well.