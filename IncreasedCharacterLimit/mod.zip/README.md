# NoFireFurnitureDamage
Burning fire should no longer break furniture. Requested by Nifty.