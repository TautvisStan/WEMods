# IncreasedCharacterLimit
This mod will remove the max 50 character limit in game options and will let you to set it any number up to your total roster size, so you will be able to have more than 50 wrestlers in a single match.

Credits: IngoH for original version of this mod.