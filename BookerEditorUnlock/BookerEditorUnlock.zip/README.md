# PromotionEditorUnlock
This mod unlocks the promotion editor by bypassing the requirements, meaning that you can still keep track of your achievements.